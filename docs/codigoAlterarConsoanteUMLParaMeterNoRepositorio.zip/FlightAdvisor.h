#ifndef FLIGHTADVISOR_H_
#define FLIGHTADVISOR_H_

#include <vector>

class Airport;
class FlightPath;

class FlightAdvisor {
private:
	std::vector<Airport > airports;
	Airport airport;
	Airport destination;

public:
	FlightPath getBestRoute(Airport source, Airport destination);
	std::vector<FlightPath > getBestRoutes(Airport source);
	std::vector<FlightPath> getAllRoutes();
};

#endif
