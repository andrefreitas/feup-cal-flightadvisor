#ifndef LOCALIZATION_H_
#define LOCALIZATION_H_


class Localization {
private:
	double latitude;
	double longitude;
public:
	Localization(double la, double lo);
	double distance(Localization &a, Localization &b);

	//Object nearest(t target, vector<object > objects);
	void nearest();
};


#endif
