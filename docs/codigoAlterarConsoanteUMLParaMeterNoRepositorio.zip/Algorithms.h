#ifndef ALGORITHMS_H_
#define ALGORITHMS_H_

class Algorithms {
public:
	void pdijkstra();
};


#endif
