#include "FlightAdvisor.h"
#include "Airport.h"
#include "FlightPath.h"

FlightPath FlightAdvisor::getBestRoute(Airport source, Airport destination) {
	return new FlightPath();
}

std::vector<FlightPath > FlightAdvisor::getBestRoutes(Airport source) {
	return new std::vector<FlightPath >;
}

std::vector<FlightPath> FlightAdvisor::getAllRoutes() {
	return new std::vector<FlightPath >;
}
