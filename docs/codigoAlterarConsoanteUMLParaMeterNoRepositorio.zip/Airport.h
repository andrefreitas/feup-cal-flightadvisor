#ifndef AIRPORT_H_
#define AIRPORT_H_

#include <string>
class Localization;

class Airport {
private:
	std::string codeName;
	Localization localization;
public:
	Airport(std::string name, Localization gps);
	Localization getLocalization();
	std::string getCodeName();
};

#endif
