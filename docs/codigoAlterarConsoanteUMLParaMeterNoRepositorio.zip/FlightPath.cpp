#include "FlightPath.h"
#include "Airport.h"

bool FlightPath::addAirport(Airport a) {
	return true;
}

std::vector<Airport > FlightPath::getPath() {
	return path;
}

double FlightPath::getDistance() {
	return distance;
}

Airport FlightPath::getSource() {
	return path[0];
}

Airport FlightPath::getDestination() {
	return path[path.size-1];
}

std::vector<Airport > FlightPath::getIntermediateAirports() {
	return path;
}

