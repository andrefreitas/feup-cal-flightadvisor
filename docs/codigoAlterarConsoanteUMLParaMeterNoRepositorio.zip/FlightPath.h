#ifndef FLIGHTPATH_H_
#define FLIGHTPATH_H_

#include <vector>
class Airport;

class FlightPath {
private:
	std::vector<Airport > path;
	double distance;

public:
	bool addAirport(Airport a);
	std::vector<Airport > getPath();
	double getDistance();
	Airport getSource();
	Airport getDestination();
	std::vector<Airport > getIntermediateAirports();
};


#endif
