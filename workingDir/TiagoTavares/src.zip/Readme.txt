Colocar aqui descrições, apontamentos e changelogs. Ir ao wikipedia ler dicas sobre readme files.
