#ifndef _EDGETYPE_
#define _EDGETYPE_

class EdgeType {
 public: 
  const static int UNDIRECTED = 0;
  const static int DIRECTED = 1;
};

#endif
